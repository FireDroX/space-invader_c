/// INITIALISATION DES MODULES
#include <ncurses.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <time.h>










/// DECLARATIONS DES FONCTONS DE GESTION DU TERMINAL
void color(int pair, int cT, int cF);
char nb_getch();
char b_getch();
void startscr();










/// DECLARATION DES FONCTONS DE GESTION DU JEU
void loadStart(int minY, int maxY, int minX, int maxX);
void stars(int maxY, int maxX);
void afficherMenu(int choix);
void map(int minY, int maxY, int minX, int maxX);
int vaisseau(char *Player, int x, int minX, int maxX, int minY, int maxY);
void deleteRow(int x, int maxY);
char *modif(char *player);










/// FONCTION PRINCIPALE
int main(){
  // Déclaration des contantes
  const int MIN_Y = 5;
  const int MAX_Y = 30;
  const int MIN_X = 10;
  const int MAX_X = 60;

  // Déclaration des variables
  char *Player = "V";
  
  bool again = true;
  int choix = 1;
  
  int x = 35;
  int score = 0;
  int vies = 3;
  
  // Les instructions avant le début du jeu
  startscr();

  // Affichage de l'écran d'accueil
  loadStart(MIN_Y, MAX_Y, MIN_X, MAX_X);
  
  // Affichage des menus
  afficherMenu(choix);
  while(again){
    switch(getch()){
      case KEY_DOWN:
        (choix == 4) ? choix = 1 : choix++;
        afficherMenu(choix);
        break;
      case KEY_UP:
        (choix == 1) ? choix = 4 : choix--;
        afficherMenu(choix);
        break;
      case '\n':
        if(choix == 1 || choix == 4) again = false;
        if(choix == 3) Player = modif(Player);
        afficherMenu(choix);
        break;
    }
  }
  clear();
    
  // Dans la boucle while les instruction pour le jeu
  while(choix == 1){
    // Affichages
    map(MIN_Y, MAX_Y, MIN_X, MAX_X);
    x = vaisseau(Player, x, MIN_X, MAX_X, MIN_Y, MAX_Y);
    
    refresh();
  }

  // Les instructions avant la cloture du programme
  //b_getch();
  
  endwin();
  return 0;
}










/// DEFINITIONS DES FONCTONS DE GESTION DU TERMINAL
/*-------------------------------------------------------------*/
/* Choix des couleurs de la police et de la fenetre CONSOLE    */
/*-------------------------------------------------------------*/
void color(int pair, int cT,int cF){
    init_pair(pair,cT,cF);
    attron(COLOR_PAIR(pair));
}



/*-------------------------------------------------------------*/
/* Retourne la touche pressee sans bloquer le deroulement      */
/*-------------------------------------------------------------*/
char nb_getch(){
    timeout(0);
    return getch();
}



/*-------------------------------------------------------------*/
/* Retourne la touche pressee en bloquant le deroulement       */
/*-------------------------------------------------------------*/
char b_getch(){
    timeout(-1);
    return getch();
}



/*-------------------------------------------------------------*/
/* Initialise l'ecran                                          */
/*-------------------------------------------------------------*/
void startscr(){
    initscr();
    start_color();
    cbreak();
    //noecho();
    curs_set(0);
    keypad(stdscr, true);
}










/// DEFINITION DES FONCTONS DE GESTION DU JEU
/*-------------------------------------------------------------*/
/* Charge le jeu                                               */
/*-------------------------------------------------------------*/
void loadStart(int minY, int maxY, int minX, int maxX){
  char *falcon[21] = {
    "          # # # # # # #",
    "        `--._________.--'",
    "      `.  /._________.\\  .'",
    "    `.     /         \\     .'",
    "   \\  \\     /       \\     /  /",
    "  |          /`---'\\          |",
    "  .=----~~~~~\\     /~~~~~----=.",
    "   [::::::::|  (_)  |::::::::]",
    "  `=----.____/  #  \\____.----='",
    "  |           +---+  \\  _.-~  |",
    "   /  /      \\|   |/ .-~    _.-'",
    "    .~  `=='\\ |   | /   _.-'.  |",
    "     /.~ __\\  |   |  /   ~.|   |",
    "      / .--~  |   |  ~--. \\|   |",
    "       /    __|   |__    \\  /_\\",
    "        /     |   |     \\    _",
    "         //  ||___||  \\\\",
    "          // ||   || \\\\",
    "           //||   ||\\\\",
    "            /_|   |_\\",
    "             _     _",
  };
  /*
             _     _
            /_|   |_\
           //||   ||\\
          // ||   || \\
         //  ||___||  \\
        /     |   |     \    _
       /    __|   |__    \  /_\
      / .--~  |   |  ~--. \|   |
     /.~ __\  |   |  /   ~.|   |
    .~  `=='\ |   | /   _.-'.  |
   /  /      \|   |/ .-~    _.-'
  |           +---+  \  _.-~  |
  `=----.____/  #  \____.----='
   [::::::::|  (_)  |::::::::]
  .=----~~~~~\     /~~~~~----=.
  |          /`---'\          |
   \  \     /       \     /  /
    `.     /         \     .'
      `.  /._________.\  .'
        `--._________.--'    
          # # # # # # #
  */
  
  clear();

  for(int y = maxY + 25; y >= 0; y--){
    move(y, minX + 3);
    for(int i = 0; i < 21; i++){
      if(i == 0) color(2, COLOR_BLUE, COLOR_BLACK);
      else color(1, 8, COLOR_BLACK);

      move(y - i, minX + 3);
      if(!(y - i <= 0) && !(y - i >= maxY)) printw(falcon[i]);
    }
    
    stars(maxY, maxX);
    refresh();
    
    usleep(50000);
    clear();
  }

  sleep(1);
  
  /*
   _____
  / ____|
 | (___  _ __   __ _  ___ ___
  \___ \| '_ \ / _` |/ __/ _ \
  ____) | |_) | (_| | (_|  __/
 |_____/| .__/ \__,_|\___\___|
 |_   _|| |                | |
   | |  |_|___   ____ _  __| | ___ _ __ 
   | | | '_ \ \ / / _` |/ _` |/ _ \ '__|
  _| |_| | | \ V / (_| | (_| |  __/ |
 |_____|_| |_|\_/ \__,_|\__,_|\___|_|
  */
  move(minY, 0);
  color(1, COLOR_YELLOW, COLOR_BLACK);
  printw("\t     _____\n");
  printw("\t    / ____|\n");
  printw("\t   | (___  _ __   __ _  ___ ___\n");
  printw("\t    \\___ \\| '_ \\ / _` |/ __/ _ \\\n");
  printw("\t    ____) | |_) | (_| | (_|  __/\n");
  printw("\t   |_____/| .__/ \\__,_|\\___\\___|\n");
  printw("\t   |_   _|| |                | |\n");
  printw("\t     | |  |_|___   ____ _  __| | ___ _ __ \n");
  printw("\t     | | | '_ \\ \\ / / _` |/ _` |/ _ \\ '__|\n");
  printw("\t    _| |_| | | \\ V / (_| | (_| |  __/ |\n");
  printw("\t   |_____|_| |_|\\_/ \\__,_|\\__,_|\\___|_|");

  
  stars(maxY, maxX);
  refresh();

  sleep(1);
  move(maxY - 2, minX);
  color(2, 8, COLOR_BLACK);
  printw("\tAppuyer pour commencer...");
  getch();
}



/*-------------------------------------------------------------*/
/* Affiche des étoiles                                         */
/*-------------------------------------------------------------*/
void stars(int maxY, int maxX){
  time_t t;
  srand((unsigned) time(&t));
  
  for(int y = 0; y < maxY; y++){
    for(int x = 0; x < maxX; x++){
      if(rand() % 50 == 5){
        move(y, x);
        color(3, COLOR_WHITE, COLOR_BLACK);
        printw(".");
      }
    }
  }
}



/*-------------------------------------------------------------*/
/* Affiche le menu                                             */
/*-------------------------------------------------------------*/
void afficherMenu(int choix){
  clear();

  /*
  ___  ___   _    ___  ___              
 / __|| _ \ /_\  / __|| __|             
 \__ \|  _// _ \| (__ | _|              
 |___/|_| /_/ \_\\___||___|             
                                        
  ___  _  _ __   __ _    ___   ___  ___ 
 |_ _|| \| |\ \ / //_\  |   \ | __|| _ \
  | | | .` | \ V // _ \ | |) || _| |   /
 |___||_|\_|  \_//_/ \_\|___/ |___||_|_\
                                        

          ___  ___   _    ___  ___              
         / __|| _ \\ /_\\  / __|| __|             
     ____\\__ \\|  _// _ \\| (__ | _|_____________________________            
    / _______/|_| /_/ \\_\\\\___||_______________________________ \\
   / /                                                        \\ \\
  | |                                                          | |
  | |                                                          | |
  | |                                                          | |
  | |                                                          | |
  | |                       <Your text>                        | |
  | |                                                          | |
  | |                                                          | |
  | |                                                          | |
  | |                                                          | |
   \\ \\________________  _  _ __   __ _    ___   ___  _________\/ \/
    \\_______________ _|| \\| |\\ \\ / //_\\  |   \\ | __|| _ \\______\/
                   | | | .` | \\ V // _ \\ | |) || _| |   /
                  |___||_|\\_|  \\_//_/ \\_\\|___/ |___||_|_\\
  
  */

  move(0, 0);
  color(1, COLOR_WHITE, COLOR_BLACK);
  printw(
"          ___  ___   _    ___  ___\n"
"         / __|| _ \\ /_\\  / __|| __|\n"             
"     ____\\__ \\|  _// _ \\| (__ | _|____________________________\n"            
"    / _______/|_| /_/ \\_\\\\___||______________________________ \\\n"
"   / /                                                       \\ \\\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"  | |                                                         | |\n"
"   \\ \\________________  _  _ __   __ _    ___   ___  ________/ /\n"
"    \\_______________ _|| \\| |\\ \\ / //_\\  |   \\ | __|| _ \\_____/\n"
"                   | | | .` | \\ V // _ \\ | |) || _| |   /\n"
"                  |___||_|\\_|  \\_//_/ \\_\\|___/ |___||_|_\\"
  );

  move(7, 31);
  (choix == 1) ? color(2, COLOR_YELLOW, COLOR_BLACK) : color(1, COLOR_WHITE, COLOR_BLACK);
  printw("Jouer");

  move(8, 27);
  (choix == 2) ? color(2, COLOR_YELLOW, COLOR_BLACK) : color(1, COLOR_WHITE, COLOR_BLACK);
  printw("Regles du jeu");

  move(9, 25);
  (choix == 3) ? color(2, COLOR_YELLOW, COLOR_BLACK) : color(1, COLOR_WHITE, COLOR_BLACK);
  printw("Parametres du jeu");

  move(10, 23);
  (choix == 4) ? color(2, COLOR_YELLOW, COLOR_BLACK) : color(1, COLOR_WHITE, COLOR_BLACK);
  printw("Quitter l application");

  refresh();
}



/*-------------------------------------------------------------*/
/* Affiche le contour du jeu                                   */
/*-------------------------------------------------------------*/
void map(int minY, int maxY, int minX, int maxX){
  // Couleur
  color(1, COLOR_WHITE, COLOR_BLACK);
  
  // Cadre
  for(int y = minY; y < maxY+1; y++){
    for(int x = minX; x < maxX+1; x++){
      move(y, x);
      if(x == minX || x == maxX) printw("|");
    }
  }

  // Partie de droite
  move(minY, maxX+7);
  printw("Space Invader");
  move(minY+2, maxX+2);
  printw("Score : ");
  move(minY+3, maxX+2);
  printw("Vies : ");
}



/*-------------------------------------------------------------*/
/* Affiche le vaisseau et le déplace avec "q" ou "d"           */
/*-------------------------------------------------------------*/
int vaisseau(char *Player, int x, int minX, int maxX, int minY, int maxY){
  // Couleur
  color(2, 8, COLOR_BLACK);

  // Déplacement + réception des touches
  move(maxY, x);

  //attron(A_REVERSE);
  printw(Player);
  //attroff(A_REVERSE);
  
  switch(getch()){
    case KEY_RIGHT:
      if(x < maxX-3) x++;
      break;
    case KEY_LEFT:
      if(x > minX+3) x--;
      break;
    case ' ':
      break;
  }
  deleteRow(x, maxY);

  // Renvoit de x
  return x;
}




/*-------------------------------------------------------------*/
/* Supprime le caractère à gauche ainsi qu'a droite            */
/*-------------------------------------------------------------*/
void deleteRow(int x, int maxY){
  // Suppression droite
  move(maxY, x + 1);
  printw("  ");

  // Suppression gauche
  move(maxY, x - 2);
  printw("  ");
}



/*-------------------------------------------------------------*/
/* Affiche les paramètres du jeu                               */
/*-------------------------------------------------------------*/
char *modif(char *Player){
  clear();

  color(1, COLOR_WHITE, COLOR_BLACK);
  printw("Vaisseau actuel : %s", Player);

  // Selection d'un personnage Yoda / Luke Skywalker / Han solo avec leur vaisseau respectif
  
  refresh();
  b_getch();
  return Player;
}


